/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author Truong Giang
 */
public class ListOfVehicle extends HashMap<String, Vehicle> {

    /**
     * Function to add vehicle into list.
     *
     * @param vehicle
     * @return
     */
    public boolean addVehicle(Vehicle vehicle) {
        this.put(vehicle.getVehicleID(), vehicle);
        return this.containsKey(vehicle.getVehicleID());
    }

    /**
     * Function to search vehicle by code. Return the vehicle has the given
     * code.
     *
     * @param code
     * @return
     */
    public Vehicle searchByCode(String code) {
        try {
            return this.get(code);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Function to search vehicle by name.
     *
     * @param name
     * @param tempList
     */
    public void searchByName(String name, ArrayList tempList) {
        for (Vehicle values : this.values()) {
            if (values.getName().equalsIgnoreCase(name)) {
                tempList.add(values);
            }
        }
    }

    /**
     * Function to search vehicle by code and put the result into temporary
     * list.
     *
     * @param code
     * @param tempList
     */
    public void searchByCode(String code, ArrayList tempList) {
        for (Vehicle values : this.values()) {
            if (values.getVehicleID().equalsIgnoreCase(code)) {
                tempList.add(values);
            }
        }
    }

    /**
     * Function to search vehicles by price and put the result into temporary
     * list.
     *
     * @param price
     * @param tempList
     */
    public void searchByPrice(double price, ArrayList tempList) {
        for (Vehicle vehicle : this.values()) {
            if (price > vehicle.getPrice()) {
                tempList.add(vehicle);
            }
        }
    }

    /**
     * Function to search vehicle by year and put into temporary list.
     *
     * @param year
     * @param tempList
     */
    public void searchByYear(int year, ArrayList tempList) {
        for (Vehicle vehicle : this.values()) {
            if (year <= vehicle.getProductYear()) {
                tempList.add(vehicle);
            }
        }
    }

    /**
     * Function to check whether the car name inputted are already exist or not.
     *
     * @param carName
     * @return
     */
    public boolean containCarName(String carName) {
        boolean check = false;
        for (Vehicle values : this.values()) {
            if (values.getName().equalsIgnoreCase(carName)) {
                check = true;
                break;
            }
        }
        return check;
    }
}
