/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Tools.Tools;
import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Truong Giang
 */
public class ColorTableOfACar implements Serializable {

    //Attribute
    private String carName;
    private ArrayList<String> list;

    //constructor
    public ColorTableOfACar(String carName) {
        this.carName = carName;
        this.list = new ArrayList<>();
    }

    public ColorTableOfACar(String carName, ArrayList list) {
        this.carName = carName;
        this.list.addAll(list);
    }

    //getter and setter
    public String getCarName() {
        return carName;
    }

    public void setCarName(String carName) {
        this.carName = carName;
    }

    public ArrayList<String> getList() {
        return this.list;
    }

    /**
     * Function to display color table of a vehicle.
     */
    public void display() {
        for (int i = 0; i < this.list.size(); i++) {
            System.out.println((i + 1) + ": " + this.list.get(i));
        }
    }

    /**
     * Function to add color into the color table.
     */
    public void addColor() {
        do {
            System.out.println("---------------------------------------");
            this.list.add(Tools.inputString("Enter color:"));
            System.out.println("---------------------------------------");
        } while (Tools.yesNoQuestion("Enter your answer(Y/N):"));
    }
}
