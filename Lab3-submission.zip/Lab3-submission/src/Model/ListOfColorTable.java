/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.HashMap;

/**
 *
 * @author Truong Giang
 */
public class ListOfColorTable extends HashMap<String, ColorTableOfACar> {

    /**
     * Function to create new color table of a vehicle.
     *
     * @param carName
     * @param list
     */
    public void newColorTableOfCar(String carName, ListOfVehicle list) {
        if (!this.containsKey(carName) && list.containCarName(carName)) {
            ColorTableOfACar table = new ColorTableOfACar(carName);
            table.addColor();
            this.put(carName, table);
        } else if (this.containsKey(carName)) {
            this.get(carName).addColor();
        } else {
            System.err.println("There are no kind of that car in the showroom");
        }
    }

    /**
     * Function to update color table of a vehicle.
     *
     * @param oldName
     * @param newName
     */
    public void updateTable(String oldName, String newName) {
        ColorTableOfACar table = new ColorTableOfACar(newName, this.get(oldName).getList());
        this.remove(oldName);
        this.put(newName, table);
    }
}
