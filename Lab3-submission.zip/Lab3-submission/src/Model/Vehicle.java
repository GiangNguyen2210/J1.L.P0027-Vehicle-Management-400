/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.Serializable;

/**
 *
 * @author Truong Giang
 */
public class Vehicle implements Comparable<Vehicle>, Serializable {

    //Attribute
    public static final String V_ID = "V\\d{4}";
    private String vehicleID;
    private String name;
    private int color;
    private double price;
    private String brand;
    private int type;
    private int productYear;

    //constructor
    public Vehicle(String vehicleID, String name, int color, double price, String brand, int type, int productYear) {
        this.vehicleID = vehicleID;
        this.name = name;
        this.color = color;
        this.price = price;
        this.brand = brand;
        this.type = type;
        this.productYear = productYear;
    }

    public Vehicle() {
        this.brand = "";
        this.color = 0;
        this.name = "";
        this.price = 0;
        this.productYear = 0;
        this.type = 0;
        this.vehicleID = "";
    }

    //getter and setter
    public String getVehicleID() {
        return vehicleID;
    }

    public void setVehicleID(String vehicleID) {
        this.vehicleID = vehicleID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getProductYear() {
        return productYear;
    }

    public void setProductYear(int productYear) {
        this.productYear = productYear;
    }

    @Override
    public String toString() {
        return String.format("| %20s | %20s | %20d | %20s | %20f | %20d | %20d |", this.vehicleID, this.name, this.color, this.brand, this.price, this.type, this.productYear);
    }

    @Override
    public int compareTo(Vehicle o) {
        return -this.getName().compareTo(o.getName());
    }

}
