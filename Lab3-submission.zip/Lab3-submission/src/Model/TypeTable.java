/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;
import Tools.Tools;

/**
 *
 * @author Truong Giang
 */
public class TypeTable extends ArrayList<String> {

    /**
     * Function to add type into table type.
     */
    public void addType() {
        do {
            System.out.println("---------------------------------");
            this.add(Tools.inputString("Enter the type:"));
            System.out.println("---------------------------------");
        } while (Tools.yesNoQuestion("Enter your answer(Y/N):"));
    }

    /**
     * Function to display type table.
     */
    public void display() {
        for (int i = 0; i < this.size(); i++) {
            System.out.println((i + 1) + ": " + this.get(i));
        }
    }
}
