/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tools;

import java.io.IOException;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author Truong Giang
 */
public class Tools {

    /**
     * The function to input string value and display the massage suggests what
     * should be inputted. Return the inputted string.
     *
     * @param mess
     * @return
     */
    public static String inputString(String mess) {
        Scanner sc = new Scanner(System.in);
        System.out.println(mess);
        return sc.nextLine();
    }

    /**
     * The function to input integer value. Check the inputted value whether it
     * is greater or lesser the given boundary Return the inputted integer.
     *
     * @param mess
     * @param lowerBound
     * @param upperBound
     * @return
     */
    public static int inputInt(String mess, int lowerBound, int upperBound) {
        int inputtedNumber = 0;
        try {
            inputtedNumber = Integer.parseInt(inputString(mess));
            if (inputtedNumber < lowerBound || inputtedNumber > upperBound) {
                inputtedNumber = 0;
            }
        } catch (NumberFormatException e) {
            System.out.println("Please enter integer!!!");
            inputtedNumber = 0;
        }
        return inputtedNumber;
    }

    /**
     * The function to input double value. Check whether it is greater or lesser
     * the given boundary. Return the inputted double.
     *
     * @param mess
     * @param lowerBound
     * @return
     */
    public static double inputDouble(String mess, int lowerBound) {
        double inputtedDouble = 0;
        try {
            inputtedDouble = Double.parseDouble(inputString(mess));
            if (inputtedDouble < lowerBound) {
                inputtedDouble = 0;
            }
        } catch (NumberFormatException e) {
            System.out.println("Please enter double!!!");
            inputtedDouble = 0;
        }
        return inputtedDouble;
    }

    /**
     * Function to get current year.
     *
     * @return
     */
    public static int getCurrentYear() {
        Calendar calendar = Calendar.getInstance();
        return calendar.get(Calendar.YEAR);
    }

    /**
     * Function return boolean value base on the answer of user (yes/no
     * question).
     *
     * @param mess
     * @return
     */
    public static boolean yesNoQuestion(String mess) {
        String s = "";
        do {
            s = inputString(mess);
        } while (!s.equalsIgnoreCase("Y") && !s.equalsIgnoreCase("N"));
        boolean check = true;
        if (s.equalsIgnoreCase("N")) {
            check = false;
        }
        return check;
    }
}
