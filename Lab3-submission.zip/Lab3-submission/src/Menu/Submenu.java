/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Menu;

import Controller.*;

/**
 *
 * @author Truong Giang
 */
public class Submenu {

    /**
     * Submenu of searching function.
     *
     * @param vc
     */
    public void search(VehicleController vc) {
        String menu = "=========================================================\n"
                + "|                     SEARCH MENU                       |\n"
                + "|                     1:Search name.                    |\n"
                + "|                     2:Search ID.                      |\n"
                + "|                     3:Turn back.                      |\n"
                + "=========================================================\n";
        int option = 0;
        do {
            option = Tools.Tools.inputInt(menu, 1, 3);
            switch (option) {
                case 1:
                    vc.searchVehicleByName();
                    break;
                case 2:
                    vc.searchVehicleByCode();
                    break;
                case 3:
                    break;
            }
        } while (option != 3);
    }

    /**
     * Submenu of showing vehicles.
     *
     * @param vc
     */
    public void show(VehicleController vc) {
        String menu = "=========================================================\n"
                + "|                      DISPLAY MENU                     |\n"
                + "|                      1:Show all.                      |\n"
                + "|                      2:Show by price.                 |\n"
                + "|                      3:Turn back.                     |\n"
                + "=========================================================\n";
        int option = 0;
        do {
            option = Tools.Tools.inputInt(menu, 1, 3);
            switch (option) {
                case 1:
                    vc.showAll();
                    break;
                case 2:
                    vc.showByPrice();
                    break;
                case 3:
                    break;
            }
        } while (option != 3);
    }

    /**
     * Submenu of printing vehicles.
     *
     * @param vc
     */
    public void print(VehicleController vc) {
        String menu = "=========================================================\n"
                + "|                      PRINT MENU                       |\n"
                + "|                      1:Print all.                     |\n"
                + "|                      2:Print by year.                 |\n"
                + "|                      3:Tunr back.                     |\n"
                + "=========================================================\n";
        int option = 0;
        do {
            option = Tools.Tools.inputInt(menu, 1, 3);
            switch (option) {
                case 1:
                    vc.printAll();
                    break;
                case 2:
                    vc.printByYear();
                    break;
                case 3:
                    break;
            }
        } while (option != 3);
    }

    /**
     * Submenu of color and type table.
     *
     * @param tc
     * @param vc
     */
    public void table(TableController tc, VehicleController vc) {
        String menu = "=========================================================\n"
                + "|                      TABLE MENU                       |\n"
                + "|                      1:Add color.                     |\n"
                + "|                      2:Add type.                      |\n"
                + "|                      3:Turn back.                     |\n"
                + "=========================================================\n";
        int option = 0;
        do {
            option = Tools.Tools.inputInt(menu, 1, 3);
            switch (option) {
                case 1:
                    tc.addColor(vc.getListOfColorTable(), vc.getListOfVehicle());
                    break;
                case 2:
                    tc.addType(vc.getTypeTable());
                    break;
                case 3:
                    break;
            }
        } while (option != 3);
    }
}
