/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Menu;

import Controller.*;

/**
 *
 * @author Truong Giang
 */
public class MainMenu {

    private Submenu submenu;
    private VehicleController vehicleController;
    private TableController tableController;

    //Constructor
    public MainMenu() {
        this.submenu = new Submenu();
        this.tableController = new TableController();
        this.vehicleController = new VehicleController(tableController, "./Vehicle.dat");
    }

    /**
     * Function to run the whole program.
     */
    public void run() {
        String menu = "=========================================================\n"
                + "|                      MAIN MENU                        |\n"
                + "|                      1:Add vehicle.                   |\n"
                + "|                      2:Check existed.                 |\n"
                + "|                      3:Update.                        |\n"
                + "|                      4:Delete.                        |\n"
                + "|                      5:Search.                        |\n"
                + "|                      6:Display.                       |\n"
                + "|                      7:Save.                          |\n"
                + "|                      8:Print.                         |\n"
                + "|                      9:Load.                          |\n"
                + "|                      10:Table.                        |\n"
                + "|                      11:Exit.                         |\n"
                + "=========================================================\n";
        int option = 0;
        do {
            option = Tools.Tools.inputInt(menu, 1, 11);
            switch (option) {
                case 1:
                    vehicleController.addVehicle();
                    break;
                case 2:
                    vehicleController.checkExistInFIle();
                    break;
                case 3:
                    vehicleController.updateVehicle();
                    break;
                case 4:
                    vehicleController.deleteVehicle();
                    break;
                case 5:
                    submenu.search(vehicleController);
                    break;
                case 6:
                    submenu.show(vehicleController);
                    break;
                case 7:
                    vehicleController.saveToFile();
                    tableController.save();
                    break;
                case 8:
                    submenu.print(vehicleController);
                    break;
                case 9:
                    vehicleController.loadFromFile();
                    tableController.load();
                    tableController.loadColorTable();
                    break;
                case 10:
                    submenu.table(tableController, vehicleController);
                    break;
                case 11:
                    break;
            }
        } while (option != 11);
    }

}
