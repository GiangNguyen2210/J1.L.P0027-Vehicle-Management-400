/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.ColorTableOfACar;
import Model.ListOfColorTable;
import Model.TypeTable;
import Tools.Tools;
import Model.ListOfVehicle;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 *
 * @author Truong Giang
 */
public class TableController {

    private ListOfColorTable listOfColorTable;
    private TypeTable typeTable;

    //constructor
    public TableController() {
        this.listOfColorTable = new ListOfColorTable();
        this.typeTable = new TypeTable();
    }

    //Getter and setter
    public ListOfColorTable getListOfColorTable() {
        return listOfColorTable;
    }

    public void setListOfColorTable(ListOfColorTable listOfColorTable) {
        this.listOfColorTable = listOfColorTable;
    }

    public TypeTable getTypeTable() {
        return typeTable;
    }

    public void setTypeTable(TypeTable typeTable) {
        this.typeTable = typeTable;
    }

    //Function
    /**
     * Controller to run the function newColorTableOfCar.
     *
     * @param list
     * @param listVehicle
     */
    public void addColor(ListOfColorTable list, ListOfVehicle listVehicle) {
        list.newColorTableOfCar(Tools.inputString("Enter the car name you want to add color:"), listVehicle);
    }

    /**
     * Controller to add new type.
     *
     * @param typeTable
     */
    public void addType(TypeTable typeTable) {
        typeTable.addType();
    }

    /**
     * Controller to save color table and type table into file.
     */
    public void save() {
        try {
            File file = new File("./typeTable.dat");
            FileOutputStream fos = new FileOutputStream(file);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            for (String s : typeTable) {
                oos.writeObject(s);
            }
            oos.close();
            fos.close();
            File file1 = new File("./listOfColorTable.dat");
            FileOutputStream fos1 = new FileOutputStream(file1);
            ObjectOutputStream oos1 = new ObjectOutputStream(fos1);
            for (ColorTableOfACar t : listOfColorTable.values()) {
                oos1.writeObject(t);
            }
            oos.close();
            fos.close();
        } catch (Exception e) {

        }
    }

    /**
     * Controller to load data from file into type table.
     */
    public void load() {
        try {
            File file = new File("./typeTable.dat");
            FileInputStream fis = new FileInputStream(file);
            ObjectInputStream ois = new ObjectInputStream(fis);
            while (true) {
                Object o = ois.readObject();
                if (o instanceof String) {
                    String s = (String) o;
                    typeTable.add(s);
                } else {
                    break;
                }
            }
            fis.close();
            ois.close();
        } catch (Exception e) {

        }
    }

    /**
     * Controller to load data into color table.
     */
    public void loadColorTable() {
        try {
            File file1 = new File("./listOfColorTable.dat");
            FileInputStream fis1 = new FileInputStream(file1);
            ObjectInputStream ois1 = new ObjectInputStream(fis1);
            while (true) {
                ColorTableOfACar o1 = (ColorTableOfACar) ois1.readObject();
                if (o1 != null) {
                    listOfColorTable.put(o1.getCarName(), o1);
                } else {
                    break;
                }
            }
            fis1.close();
            ois1.close();
        } catch (Exception e) {

        }
    }

}
