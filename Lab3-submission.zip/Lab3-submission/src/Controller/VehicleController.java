/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.ListOfColorTable;
import Model.ListOfVehicle;
import Model.TypeTable;
import Model.Vehicle;
import View.VehicleInteraction;
import Tools.Tools;

/**
 *
 * @author Truong Giang
 */
public class VehicleController {

    //Attribute
    private VehicleInteraction vehicleView;
    private ListOfVehicle listOfVehicle;
    private ListOfColorTable listOfColorTable;
    private TypeTable typeTable;

    //Constructor
    public VehicleController(TableController tc, String path) {
        this.vehicleView = new VehicleInteraction(path);
        this.listOfColorTable = tc.getListOfColorTable();
        this.typeTable = tc.getTypeTable();
        this.listOfVehicle = new ListOfVehicle();

    }

    //getter and setter
    public VehicleInteraction getVehicleView() {
        return vehicleView;
    }

    public void setVehicleView(VehicleInteraction vehicleView) {
        this.vehicleView = vehicleView;
    }

    public ListOfVehicle getListOfVehicle() {
        return listOfVehicle;
    }

    public void setListOfVehicle(ListOfVehicle listOfVehicle) {
        this.listOfVehicle = listOfVehicle;
    }

    public ListOfColorTable getListOfColorTable() {
        return listOfColorTable;
    }

    public void setListOfColorTable(ListOfColorTable listOfColorTable) {
        this.listOfColorTable = listOfColorTable;
    }

    public TypeTable getTypeTable() {
        return typeTable;
    }

    public void setTypeTable(TypeTable typeTable) {
        this.typeTable = typeTable;
    }

    //Function
    /**
     * Function to create new vehicle object and pass to addNewVehicle function
     * in vehicle view.
     */
    public void addVehicle() {
        boolean check = true;
        do {
            Vehicle vehicle = new Vehicle();
            check = vehicleView.addNewVehicle(vehicle, listOfVehicle, listOfColorTable, typeTable);
            if (check) {
                System.err.println("Adding succesfully!!!");
            } else {
                System.err.println("Fail!!!");
            }
            check = Tools.yesNoQuestion("Do you want to keep adding Vehicle?");
        } while (check);
    }

    /**
     * Controller to run the function in vehicle view.
     */
    public void checkExistInFIle() {
        String code = Tools.inputString("Enter the code of the vehicle:");
        if (vehicleView.checkExistedinfile(code)) {
            System.err.println("Existed!!!!");
        } else {
            System.err.println("Not existed!!!!");
        }
    }

    /**
     * Controller to run the function in vehicle view.
     */
    public void updateVehicle() {
        String code = Tools.inputString("Enter the code you want to update:");
        Vehicle temp = listOfVehicle.searchByCode(code);
        vehicleView.updateVehicle(listOfVehicle, temp, listOfColorTable, typeTable);
    }

    /**
     * Controller to run the function in vehicle view.
     */
    public void deleteVehicle() {
        String code = Tools.inputString("Enter the code you want to delete:");
        Vehicle temp = listOfVehicle.searchByCode(code);
        vehicleView.delete(listOfVehicle, temp);
    }

    /**
     * Controller to run the function in vehicle view.
     */
    public void searchVehicleByName() {
        String name = Tools.inputString("Enter the car name you want to find:");
        vehicleView.searchByName(listOfVehicle, name);
    }

    /**
     * Controller to run the function in vehicle view.
     */
    public void searchVehicleByCode() {
        String code = Tools.inputString("Enter the code you want to find:");
        vehicleView.searchByCode(listOfVehicle, code);
    }

    /**
     * Controller to run the function in vehicle view.
     */
    public void showAll() {
        vehicleView.showAll(listOfVehicle);
    }

    /**
     * Controller to run the function in vehicle view.
     */
    public void showByPrice() {
        double temp = Tools.inputDouble("Enter the price you want:", 10000);
        vehicleView.showByPrice(listOfVehicle, temp);
    }

    /**
     * Controller to run the function in vehicle view.
     */
    public void saveToFile() {
        vehicleView.saveToFile(listOfVehicle);
    }

    /**
     * Controller to run the function in vehicle view.
     */
    public void printAll() {
        vehicleView.printAll(listOfVehicle);
    }

    /**
     * Controller to run the function in vehicle view.
     */
    public void printByYear() {
        int year = Tools.inputInt("Enter the year you want", 1900, Tools.getCurrentYear());
        vehicleView.printYear(listOfVehicle, year);
    }

    /**
     * Controller to run the function in vehicle view.
     */
    public void loadFromFile() {
        vehicleView.load(listOfVehicle);
    }
}
