/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import Model.Vehicle;
import Tools.Tools;
import Model.ListOfVehicle;
import Model.ListOfColorTable;
import Model.TypeTable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;

/**
 *
 * @author Truong Giang
 */
public class VehicleInteraction {

    private ArrayList<Vehicle> tempList; //temporary list is used to contain the vehicles when searching on conditions
    public static final String[] str = {"VEHICLEID", "NAME", "COLOR", "BRAND", "PRICE", "TYPE", "PRODUCTYEAR"};
    private String pathFile;

    /**
     * The constructor of vehicle view which is used to initialize the temporary
     * list. and the path file.
     *
     * @param fileName
     */
    public VehicleInteraction(String fileName) {
        this.tempList = new ArrayList<>();
        pathFile = fileName;
    }

    /**
     * The function show the name of each attribute of a vehicle.
     */
    public void showTag() {
        System.out.format("| %20s | %20s | %20s | %20s | %20s | %20s | %20s |\n", str[0], str[1], str[2], str[3], str[4], str[5], str[6]);
    }

    /**
     * The function to add id for a vehicle and check if the inputted id already
     * exist or not.
     *
     * @param vehicle
     * @param list
     * @return Boolean check
     */
    public boolean inputID(Vehicle vehicle, ListOfVehicle list) {
        boolean check = true;
        String inputtedID = Tools.inputString("Enter the id of the vehicle(Vxxxx):");
        if (inputtedID.matches(Vehicle.V_ID) && !list.containsKey(inputtedID)) {
            vehicle.setVehicleID(inputtedID);
            check = false;
        }
        return check;
    }

    /**
     * The function to add name for a vehicle.
     *
     * @param vehicle
     */
    public void inputName(Vehicle vehicle) {
        String inputtedName = Tools.inputString("Enter the name of the vehicle");
        if (!inputtedName.isEmpty()) {
            vehicle.setName(inputtedName);
        }
    }

    /**
     * The function to add color for the vehicle.
     *
     * @param vehicle
     * @param list
     */
    public void inputColor(Vehicle vehicle, ListOfColorTable list) {
        int inputtedColor = 0;
        if (list.containsKey(vehicle.getName())) {
            list.get(vehicle.getName()).display();
            inputtedColor = Tools.inputInt("Enter the ID color base on the table color of the vehicle:", 1, list.get(vehicle.getName()).getList().size());
        } else {
            System.out.println("There are no color table of that car, Please go and update it!!!");
        }
        if (inputtedColor != 0) {
            vehicle.setColor(inputtedColor);
        }
    }

    /**
     * The function to add price for a vehicle.
     *
     * @param vehicle
     * @param lowerBound
     */
    public void inputPrice(Vehicle vehicle, int lowerBound) {
        double inputtedPrice = Tools.inputDouble("Enter the price of the vehicle:", lowerBound);
        if (inputtedPrice != 0) {
            vehicle.setPrice(inputtedPrice);
        }
    }

    /**
     * The function to add brand for a vehicle.
     *
     * @param vehicle
     */
    public void inputBrand(Vehicle vehicle) {
        String inputtedBrand = Tools.inputString("Enter the brand of the vehicle:");
        if (!inputtedBrand.isEmpty()) {
            vehicle.setBrand(inputtedBrand);
        }
    }

    /**
     * The function to add type for a vehicle.
     *
     * @param vehicle
     * @param typeTable
     */
    public void inputType(Vehicle vehicle, TypeTable typeTable) {
        int inputtedType = 0;
        if (!typeTable.isEmpty()) {
            typeTable.display();
            inputtedType = Tools.inputInt("Enter the type of the vehicle(SHOULD BE NUMBER):", 1, typeTable.size());
        } else {
            System.out.println("The type table is empty, please go and update it!!!");
        }
        if (inputtedType != 0) {
            vehicle.setType(inputtedType);
        }
    }

    /**
     * The function to add year for a vehicle.
     *
     * @param vehicle
     */
    public void inputYear(Vehicle vehicle) {
        int inputtedYear = Tools.inputInt("Enter the produced year:", 1900, Tools.getCurrentYear());
        if (inputtedYear != 0) {
            vehicle.setProductYear(inputtedYear);
        }
    }

    /**
     * The function to create a new vehicle, it also check duplicated id. The
     * vehicle and all the list objects will be created in the controller and
     * pass to the function.
     *
     * @param vehicle
     * @param list
     * @param listColor
     * @param typeTable
     * @return
     */
    public boolean addNewVehicle(Vehicle vehicle, ListOfVehicle list, ListOfColorTable listColor, TypeTable typeTable) {
        System.out.println("==========================================================================================\n");
        while (inputID(vehicle, list)) {
            System.err.println("Please enter correctly!!!");
        }
        inputName(vehicle);
        inputColor(vehicle, listColor);
        inputPrice(vehicle, 10000);
        inputBrand(vehicle);
        inputType(vehicle, typeTable);
        inputYear(vehicle);
        boolean check = true;
        if (!list.addVehicle(vehicle)) {
            check = false;
        }
        System.out.println("==========================================================================================\n");
        return check;
    }

    /**
     * The function to check if the vehicle is saved into file or not.
     *
     * @param code
     * @return
     */
    public boolean checkExistedinfile(String code) {
        load(tempList);
        boolean check = false;
        for (Vehicle v : tempList) {
            if (v.getVehicleID().equalsIgnoreCase(code)) {
                check = true;
                break;
            }
        }
        tempList.clear();
        return check;
    }

    /**
     * The function to update information of a vehicle, it is the same as the
     * create function but does not allow user to change the id.
     *
     * @param list
     * @param vehicle
     * @param listColor
     * @param typeTable
     */
    public void updateVehicle(ListOfVehicle list, Vehicle vehicle, ListOfColorTable listColor, TypeTable typeTable) {
        if (vehicle != null) {
            System.out.println("==========================================================================================\n");
            System.out.println("UPDATE PHASE:");
            String oldName = vehicle.getName();
            inputName(vehicle);
            inputColor(vehicle, listColor);
            inputPrice(vehicle, 10000);
            inputBrand(vehicle);
            inputType(vehicle, typeTable);
            inputYear(vehicle);
            System.out.println("==========================================================================================\n");
        } else {
            System.out.println("Vehicle does not exist!!!");
        }
    }

    /**
     * The function to delete a vehicle.
     *
     * @param list
     * @param vehicle
     * @return
     */
    public boolean delete(ListOfVehicle list, Vehicle vehicle) {
        boolean check = false;
        if (vehicle != null && Tools.yesNoQuestion("Do you really want to delete the vehicle:")) {
            list.remove(vehicle.getVehicleID());
            check = true;
        } else {
            System.err.println("The vehicle does not exist!!!");
        }
        return check;
    }

    /**
     * The function to search a vehicle by name. The inputted name will be
     * inputted in the controller function.
     *
     * @param list
     * @param name
     */
    public void searchByName(ListOfVehicle list, String name) {
        System.out.println("===========================================================================================\n");
        list.searchByName(name, tempList);
        if (!tempList.isEmpty()) {
            showTag();
            for (Vehicle vehicle : tempList) {
                System.out.println(vehicle);
            }
            System.out.println("===========================================================================================\n");
            tempList.clear();
        } else {
            System.err.println("there are no car name in the show room!!!");
        }
    }

    /**
     * The function to search a vehicle by code, the same structure with search
     * by name function.
     *
     * @param list
     * @param code
     */
    public void searchByCode(ListOfVehicle list, String code) {
        System.out.println("===========================================================================================\n");
        list.searchByCode(code, tempList);
        if (!tempList.isEmpty()) {
            showTag();
            for (Vehicle vehicle : tempList) {
                System.out.println(vehicle);
            }
            System.out.println("===========================================================================================\n");
            tempList.clear();
        } else {
            System.err.println("There are no car have that id in the show room!!!");
        }
    }

    /**
     * The function to show all the vehicle in the show room.
     *
     * @param list
     */
    public void showAll(ListOfVehicle list) {
        System.out.println("===========================================================================================\n");
        showTag();
        for (Vehicle value : list.values()) {
            System.out.println(value);
        }
        System.out.println("===========================================================================================\n");
    }

    /**
     * The function to show all the vehicles by price and sort in descending
     * order.
     *
     * @param list
     * @param price
     */
    public void showByPrice(ListOfVehicle list, double price) {
        list.searchByPrice(price, tempList);
        if (!tempList.isEmpty()) {
            Collections.sort(tempList, new Comparator<Vehicle>() {
                @Override
                public int compare(Vehicle o1, Vehicle o2) {
                    return o1.getPrice() > o2.getPrice() ? -1 : o1.getPrice() < o2.getPrice() ? 1 : 0;
                }
            });
            System.out.println("===========================================================================================\n");
            showTag();
            for (Vehicle value : tempList) {
                System.out.println(value);
            }
            System.out.println("===========================================================================================\n");
            tempList.clear();
        } else {
            System.err.println("There are no car at that price!!!");
        }
    }

    /**
     * The function to save vehicles in the list to file.
     *
     * @param list
     */
    public void saveToFile(ListOfVehicle list) {
        try {
            File file = new File(pathFile);
            FileOutputStream fos = new FileOutputStream(file);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            for (Vehicle values : list.values()) {
                oos.writeObject(values);
            }
            fos.close();
            oos.close();
        } catch (Exception e) {

        }
    }

    /**
     * The function to print all vehicles.
     *
     * @param list
     */
    public void printAll(ListOfVehicle list) {
        System.out.println("===========================================================================================\n");
        showTag();
        for (Vehicle value : list.values()) {
            System.out.println(value);
        }
        System.out.println("============================================================================================\n");
    }

    /**
     * The function to print vehicles by year and display in descending order.
     *
     * @param list
     * @param year
     */
    public void printYear(ListOfVehicle list, int year) {
        list.searchByYear(year, tempList);
        if (!tempList.isEmpty()) {
            Collections.sort(tempList, new Comparator<Vehicle>() {
                @Override
                public int compare(Vehicle o1, Vehicle o2) {
                    return o1.getProductYear() > o2.getProductYear() ? -1 : o1.getProductYear() < o2.getProductYear() ? 1 : 0;
                }
            });
            System.out.println("============================================================================================\n");
            showTag();
            for (Vehicle vehicle : tempList) {
                System.out.println(vehicle);
            }
            System.out.println("============================================================================================\n");
            tempList.clear();
        } else {
            System.err.println("There are no car at that year!!!");
        }

    }

    /**
     * Function to load vehicles from file.
     *
     * @param list
     */
    public void load(ListOfVehicle list) {
        try {
            File file = new File(pathFile);
            FileInputStream fis = new FileInputStream(file);
            ObjectInputStream ois = new ObjectInputStream(fis);
            boolean check = true;
            while (check) {
                Object oj = ois.readObject();
                if (oj instanceof Vehicle) {
                    Vehicle vehicle = (Vehicle) oj;
                    list.put(vehicle.getVehicleID(), vehicle);
                } else {
                    check = false;
                }
            }
            fis.close();
            ois.close();
        } catch (Exception e) {

        }
    }

    /**
     * Function to load data from file into the temporary list to check the
     * vehicle exist in file.
     *
     * @param list
     */
    public void load(ArrayList<Vehicle> list) {
        try {
            File file = new File(pathFile);
            FileInputStream fis = new FileInputStream(file);
            ObjectInputStream ois = new ObjectInputStream(fis);
            boolean check = true;
            while (check) {
                Object oj = ois.readObject();
                if (oj instanceof Vehicle) {
                    Vehicle vehicle = (Vehicle) oj;
                    list.add(vehicle);
                } else {
                    check = false;
                }
            }
            fis.close();
            ois.close();
        } catch (Exception e) {

        }
    }

}
