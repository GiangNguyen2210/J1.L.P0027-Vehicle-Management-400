
import Menu.MainMenu;
import Model.*;
import View.VehicleInteraction;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Truong Giang
 */
public class Main {

    public static void main(String[] args) {
        MainMenu mn = new MainMenu();
        mn.run();
        
    }
}
